@echo off
cd /d %~dp0
where ollama >nul 2>nul && (curl -s localhost:11434/api/tags >nul 2>nul || start /b ollama serve)
python server.py
