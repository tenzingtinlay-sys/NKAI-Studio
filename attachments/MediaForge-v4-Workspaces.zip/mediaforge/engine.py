"""DesignForge engine: parses reference design-system files and generates designs.

Two generators share the same parsed tokens:
  * Claude (when ANTHROPIC_API_KEY is set): free-form, any design brief.
  * Local template engine (no key needed): landing / dashboard / poster.
"""
import colorsys, glob, html, json, os, re, time, urllib.request, urllib.error

BASE = os.path.dirname(os.path.abspath(__file__))
REF_DIR = os.path.join(BASE, "reference")
SKIP_HEADS = {"Tech Stack", "Design Tokens", "Tailwind Config", "Page Structure",
              "Content", "SEO", "Visual Preview", "Structured Tables", "Export Formats"}
_cache = {}


# ---------- colour helpers ----------
def _rgb(h):
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, round(v))) for v in rgb)


def _lum(h):
    r, g, b = _rgb(h)
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255


def _mix(a, b, t):
    return _hex(tuple(x + (y - x) * t for x, y in zip(_rgb(a), _rgb(b))))


def _sat(h):
    r, g, b = (v / 255 for v in _rgb(h))
    _, l, s = colorsys.rgb_to_hls(r, g, b)
    return s, l


# ---------- parsing ----------
def _first(rx, text, default=""):
    m = re.search(rx, text)
    return m.group(1).strip() if m else default


def parse_reference(path):
    t = open(path, encoding="utf-8", errors="ignore").read()
    stem = os.path.splitext(os.path.basename(path))[0]
    rid = re.sub(r"[^a-z0-9]+", "-", re.sub(r"^CONTEXT-", "", stem).lower())[:48].strip("-")
    name = re.sub(r"^CONTEXT\s*—\s*", "", _first(r"(?m)^# (.*)$", t, stem))

    palette = re.findall(r"#[0-9a-fA-F]{6}\b", _first(r"\*\*Palette:\*\* (.*)", t))
    palette = list(dict.fromkeys(p.lower() for p in palette)) or ["#ffffff", "#111111", "#5666f5"]
    scheme = _first(r"\*\*Scheme:\*\* (\w+)", t, "light")
    ordered = sorted(palette, key=_lum)
    dark = scheme == "dark"
    # Extracted "Text/Background" roles are sometimes wrong, so derive from palette luminance.
    bg, fg = (ordered[0], ordered[-1]) if dark else (ordered[-1], ordered[0])
    if abs(_lum(bg) - _lum(fg)) < 0.4:
        bg, fg = ("#0b0b0f", "#f5f5f7") if dark else ("#ffffff", "#111111")
    cands = [(_sat(c)[0], c) for c in palette if _sat(c)[0] > 0.4 and 0.2 < _sat(c)[1] < 0.8]
    accent = max(cands)[1] if cands else fg  # monochrome brands stay monochrome

    font = _first(r"\*\*Font:\*\* `([^`]*)`", t)
    family = font.split(",")[0].strip().strip("\"'") if font else "Inter"
    if not re.fullmatch(r"[A-Za-z][A-Za-z ]{1,30}", family) or family.startswith("__"):
        family = "Inter"
    radii = [int(x) for x in re.findall(r"(\d+)px", _first(r"\*\*Radius:\*\* (.*)", t)) if 0 < int(x) <= 48]
    radius = sorted(radii)[len(radii) // 2] if radii else 12
    heads = [h.strip(" *") for h in re.findall(r"(?m)^## (.*)$", t)]
    heads = [h for h in heads if h and h not in SKIP_HEADS][:12]
    comps = re.findall(r"\| (\w[\w-]*) \| (\d+) \| \d+% \|", t)
    return {
        "id": rid, "name": name, "file": os.path.basename(path),
        "url": _first(r"\| (https?://[^\s|]+)", t)[:120],
        "framework": _first(r"\*\*Framework:\*\* (.*)", t).split("—")[0].strip()[:40],
        "scheme": "dark" if dark else "light",
        "palette": palette[:10], "bg": bg, "fg": fg, "accent": accent,
        "font": family, "font_stack": font[:200], "radius": radius,
        "sizes": _first(r"\*\*Sizes:\*\* (.*)", t), "weights": _first(r"\*\*Weights:\*\* (.*)", t),
        "headings": heads, "components": [{"type": a, "count": int(b)} for a, b in comps][:8],
    }


def load_all():
    if _cache:
        return _cache
    for p in sorted(glob.glob(os.path.join(REF_DIR, "*.md"))):
        try:
            r = parse_reference(p)
            _cache.setdefault(r["id"], r)  # duplicate exports of the same page are skipped
        except Exception as e:
            print("skip", p, e)
    return _cache


def get_ref(rid):
    return load_all().get(rid)


def raw_text(ref):
    t = open(os.path.join(REF_DIR, ref["file"]), encoding="utf-8", errors="ignore").read()
    return re.sub(r"!\[[^\]]*\]\(data:[^)]*\)", "", t)  # drop inline swatch images


def raw_excerpt(ref, limit=4500):
    t = raw_text(ref)
    tw = re.search(r"## Tailwind Config(.*?)(?=\n## )", t, re.S)
    pg = re.search(r"## Page Structure(.*?)(?=\n## Content)", t, re.S)
    return ((tw.group(0)[:2500] if tw else "") + "\n" + (pg.group(0)[:1500] if pg else ""))[:limit]


# ---------- Claude generator ----------
_ol = {"t": 0.0, "ok": False}


def ollama_url():
    return os.environ.get("OLLAMA_URL", "http://localhost:11434").rstrip("/")


def ollama_model():
    return os.environ.get("OLLAMA_MODEL", "llama3.2")


def ollama_up():
    """Free local engine: true when an Ollama server is reachable (cached 5s)."""
    if time.time() - _ol["t"] < 5:
        return _ol["ok"]
    try:
        urllib.request.urlopen(ollama_url() + "/api/tags", timeout=1.5).read()
        ok = True
    except Exception:
        ok = False
    _ol.update(t=time.time(), ok=ok)
    return ok


def backend():
    """Which text engine is live: 'claude' (optional paid key), 'ollama' (free, local) or None (templates)."""
    if os.environ.get("ANTHROPIC_API_KEY"):
        return "claude"
    return "ollama" if ollama_up() else None


def llm_available():
    return backend() is not None


def _post(url, body, headers, timeout):
    req = urllib.request.Request(url, json.dumps(body).encode(), headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"LLM error {e.code}: {e.read().decode()[:300]}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"LLM unreachable: {e.reason}")


def llm_text(system, messages, max_tokens=1500):
    """One entry point for all text generation. No timeouts that cut off slow local models."""
    b = backend()
    if b == "claude":
        d = _post("https://api.anthropic.com/v1/messages",
                  {"model": os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5"), "max_tokens": max_tokens,
                   "system": system, "messages": messages},
                  {"content-type": "application/json", "anthropic-version": "2023-06-01",
                   "x-api-key": os.environ["ANTHROPIC_API_KEY"]}, 600)
        return "".join(x.get("text", "") for x in d.get("content", []))
    if b == "ollama":
        d = _post(ollama_url() + "/api/chat",
                  {"model": ollama_model(), "stream": False, "options": {"num_predict": max_tokens},
                   "messages": [{"role": "system", "content": system}] + messages},
                  {"content-type": "application/json"}, 1800)
        return (d.get("message") or {}).get("content", "")
    raise RuntimeError("No text engine available")


def _system_prompt(ref):
    return f"""You are a senior product designer and front-end engineer.
Produce ONE complete, self-contained HTML document (inline <style> and <script>, no build step,
no external assets except an optional Google Fonts <link>). Responsive, accessible, polished.
Faithfully adopt the visual language of the reference design system below: its palette, type,
radius, density and tone. Use CSS custom properties for the tokens. Never copy the brand's name,
logo or copy; invent content that fits the user's brief. Reply with the HTML only.

REFERENCE: {ref['name']} ({ref['url']})
scheme={ref['scheme']} background={ref['bg']} text={ref['fg']} accent={ref['accent']}
palette={', '.join(ref['palette'])}
font={ref['font_stack'] or ref['font']} (fallback Inter, system-ui) radius~{ref['radius']}px
sizes={ref['sizes']} weights={ref['weights']}
sections on the reference site: {'; '.join(ref['headings'])}
--- extracted config ---
{raw_excerpt(ref)}"""


def llm_generate(ref, kind, prompt, previous=None, change=None):
    if previous and change:
        user = f"Current design:\n{previous}\n\nApply this change and return the full updated HTML:\n{change}"
    else:
        user = f"Design type: {kind}\nBrief: {prompt}"
    text = llm_text(_system_prompt(ref), [{"role": "user", "content": user}], 16000)
    m = re.search(r"```(?:html)?\s*(.*?)```", text, re.S)
    text = (m.group(1) if m else text).strip()
    if "<html" not in text.lower() and "<body" not in text.lower():
        raise RuntimeError("Model did not return an HTML document. Try again or use a larger model.")
    return text


# ---------- local template generator ----------
def _brief(prompt):
    parts = [p.strip() for p in re.split(r"[.;\n]", prompt) if p.strip()]
    title = (parts[0] if parts else "Your idea, designed")[:70]
    rest = [x.strip() for p in parts[1:] for x in p.split(",") if x.strip()]
    return title, (rest + ["Fast to start", "Built to scale", "Yours to shape"])[:3]


def local_generate(ref, kind, prompt):
    e = html.escape
    bg, fg, ac = ref["bg"], ref["fg"], ref["accent"]
    onac = "#ffffff" if _lum(ac) < .6 else "#111111"
    title, feats = _brief(prompt)
    brand = e(title.split()[0].capitalize()) if title else "Brand"
    css = (f":root{{--bg:{bg};--fg:{fg};--muted:{_mix(bg, fg, .55)};--surface:{_mix(bg, fg, .06)};"
           f"--border:{_mix(bg, fg, .14)};--ac:{ac};--onac:{onac};--r:{ref['radius']}px;"
           f"--font:'{e(ref['font'])}',Inter,system-ui,sans-serif}}"
           "*{box-sizing:border-box;margin:0}body{background:var(--bg);color:var(--fg);font:16px/1.55 var(--font)}"
           "a{color:inherit;text-decoration:none}.btn{display:inline-block;padding:12px 22px;border-radius:calc(var(--r)*2);"
           "background:var(--ac);color:var(--onac);font-weight:600}.btn.ghost{background:transparent;color:var(--fg);border:1px solid var(--border)}"
           "nav{display:flex;justify-content:space-between;align-items:center;padding:20px 6vw}nav b{font-size:20px}"
           ".card{background:var(--surface);border:1px solid var(--border);border-radius:var(--r);padding:24px}"
           ".muted{color:var(--muted)}.grid{display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(220px,1fr))}")
    link = '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">'
    head = (f'<!doctype html><html lang="en"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width,initial-scale=1"><title>{e(title)}</title>{link}<style>{css}')

    if kind == "dashboard":
        bars = "".join(f'<i style="height:{h}%"></i>' for h in (40, 65, 50, 80, 60, 92, 74))
        rows = "".join(f"<tr><td>{n}</td><td>{s}</td><td>{v}</td></tr>" for n, s, v in
                       (("Project Atlas", "Active", "$12.4k"), ("Project Nova", "Review", "$8.1k"), ("Project Pulse", "Active", "$5.7k")))
        stats = "".join(f'<div class="card"><div class="muted">{k}</div><h2>{v}</h2></div>' for k, v in
                        (("Revenue", "$48.2k"), ("Users", "3,204"), ("Conversion", "4.8%"), ("Churn", "1.2%")))
        return head + (
            ".app{display:grid;grid-template-columns:220px 1fr;min-height:100vh}aside{border-right:1px solid var(--border);padding:24px}"
            "aside a{display:block;padding:10px 12px;border-radius:var(--r)}aside a:first-of-type{background:var(--surface)}"
            "main{padding:32px;display:grid;gap:20px}.bars{display:flex;align-items:flex-end;gap:12px;height:160px}"
            ".bars i{flex:1;background:var(--ac);border-radius:6px 6px 0 0}table{width:100%;border-collapse:collapse}"
            "td{padding:12px 0;border-top:1px solid var(--border)}@media(max-width:700px){.app{grid-template-columns:1fr}aside{display:none}}"
            f'</style></head><body><div class="app"><aside><b>{brand}</b><br><br><a href="#">Overview</a><a href="#">Projects</a>'
            f'<a href="#">Reports</a><a href="#">Settings</a></aside><main><h1>{e(title)}</h1><div class="grid">{stats}</div>'
            f'<div class="card"><h3>Weekly activity</h3><br><div class="bars">{bars}</div></div>'
            f'<div class="card"><h3>Recent projects</h3><table>{rows}</table></div></main></div></body></html>')

    if kind == "poster":
        return head + (
            "body{min-height:100vh;display:grid;place-items:center;text-align:center;overflow:hidden;position:relative}"
            ".blob{position:absolute;width:60vmin;height:60vmin;border-radius:50%;background:var(--ac);filter:blur(90px);opacity:.45}"
            ".in{position:relative;padding:6vw;max-width:900px}h1{font-size:clamp(44px,9vw,110px);line-height:1;letter-spacing:-.03em}"
            "p{margin:24px 0 32px;font-size:20px}</style></head>"
            f'<body><div class="blob"></div><div class="in"><h1>{e(title)}</h1>'
            f'<p class="muted">{e(feats[0])} · {e(feats[1])} · {e(feats[2])}</p><a class="btn" href="#">Learn more</a></div></body></html>')

    cards = "".join(f'<div class="card"><h3>{e(f)}</h3><p class="muted">Crafted for clarity, speed and a little delight.</p></div>' for f in feats)
    sub = e(prompt[:160]) if len(prompt) > len(title) else "A new way to build, ready in minutes."
    return head + (
        "header{padding:12vh 6vw 8vh;max-width:980px}h1{font-size:clamp(38px,6vw,72px);line-height:1.05;letter-spacing:-.025em}"
        "header p{margin:20px 0 32px;font-size:20px;max-width:620px}section{padding:0 6vw 8vh}"
        ".cta{margin:0 6vw 8vh;text-align:center;padding:56px 24px;border-radius:calc(var(--r)*1.5);background:var(--ac);color:var(--onac)}"
        ".cta .btn{background:var(--bg);color:var(--fg);margin-top:18px}footer{padding:32px 6vw;border-top:1px solid var(--border)}"
        f'</style></head><body><nav><b>{brand}</b><a class="btn ghost" href="#">Sign in</a></nav>'
        f'<header><h1>{e(title)}</h1><p class="muted">{sub}</p><a class="btn" href="#">Get started</a> <a class="btn ghost" href="#">Watch demo</a></header>'
        f'<section><div class="grid">{cards}</div></section><div class="cta"><h2>Ready when you are</h2><a class="btn" href="#">Start free</a></div>'
        f'<footer class="muted">© {brand}. Styled after {e(re.split(r' [—|:•-] ', ref['name'])[0][:40])}.</footer></body></html>')


def generate(ref_id, kind, prompt, previous=None, change=None):
    ref = get_ref(ref_id)
    if not ref:
        raise ValueError("Unknown reference")
    b = backend()
    if b:
        try:
            return llm_generate(ref, kind, prompt, previous, change), b, ref
        except RuntimeError as e:
            if previous and change:
                raise  # don't silently discard the user's current design
            print("LLM failed, using local template:", e)
    if previous and change:
        raise RuntimeError("Refining needs an AI engine. Install Ollama (free, https://ollama.com), run: ollama pull llama3.2")
    k = kind if kind in ("landing", "dashboard", "poster") else "landing"
    return local_generate(ref, k, prompt), "local", ref


claude_text = llm_text  # backwards-compatible name
