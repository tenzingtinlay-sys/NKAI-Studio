# CONTEXT — HeyGen - Apps
> Extracted by [Steal](https://steal.extension) | 2026-10-15T09:04:04.113Z | https://app.heygen.com/apps

## Tech Stack
- **Framework:** No specific framework detected — likely vanilla HTML/CSS/JS
- **Analytics:** Google Analytics, PostHog
- **CDN:** AWS CloudFront

## Design Tokens

### Colors
**Scheme:** light

| Role | Value |
|------|-------|
| Primary | `#3e4049` |
| Text | `#e2e3e6` |
| Background | `#e5e7eb` |

**Palette:** `#e5e7eb`, `#3e4049`, `#ffffff`, `#e2e3e6`, `#e3f4fa`

### Typography
**Font:** `"TT Norms Pro", Avenir, -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Helvetica Neue", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"`
**Sizes:** 14px, 16px, 28px, 21px, 12px, 36px, 18px
**Weights:** 400, 600, 700, 500

### Spacing
- **Scale:** 4px, 8px, 10px, 16px, 20px
- **Radius:** 16px, 100px
- **Breakpoints:** 375px, 480px, 481px, 600px, 640px, 641px, 721px, 761px, 768px, 860px, 890px, 900px, 961px, 1024px, 1060px, 1150px, 1280px, 1440px, 1536px, 1920px, 2000px, 2560px

### Color Swatches

| Role | Hex | Preview |
|------|-----|---------|
| Primary | `#3e4049` | ![#3e4049](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16'%3E%3Crect width='16' height='16' fill='%233e4049'/%3E%3C/svg%3E) |
| Text | `#e2e3e6` | ![#e2e3e6](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16'%3E%3Crect width='16' height='16' fill='%23e2e3e6'/%3E%3C/svg%3E) |
| Background | `#e5e7eb` | ![#e5e7eb](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16'%3E%3Crect width='16' height='16' fill='%23e5e7eb'/%3E%3C/svg%3E) |

## Tailwind Config

```js
/** @type {import('tailwindcss').Config} */
module.exports = {
  "theme": {
    "extend": {
      "colors": {
        "primary": "#3e4049",
        "bg": "#e5e7eb",
        "text": "#e2e3e6",
        "palette-1": "#e5e7eb",
        "palette-2": "#3e4049",
        "palette-3": "#ffffff",
        "palette-4": "#e2e3e6",
        "palette-5": "#e3f4fa"
      },
      "fontFamily": {
        "sans": [
          "TT Norms Pro",
          "Avenir",
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "PingFang SC",
          "Hiragino Sans GB",
          "Microsoft YaHei",
          "Helvetica Neue",
          "Helvetica",
          "Arial",
          "sans-serif",
          "Apple Color Emoji",
          "Segoe UI Emoji",
          "Segoe UI Symbol"
        ]
      },
      "borderRadius": {
        "sm": "16px",
        "md": "100px"
      },
      "fontSize": {
        "sm": "14px",
        "base": "16px",
        "lg": "28px",
        "fs3": "21px",
        "fs4": "12px",
        "fs5": "36px",
        "fs6": "18px"
      },
      "spacing": {
        "xs": "4px",
        "sm": "8px",
        "md": "10px",
        "lg": "16px",
        "xl": "20px"
      },
      "boxShadow": {
        "sm": "rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.06) 0px 2px 4px -2px, rgba(0, 0, 0, 0.1) 0px 4px 8px -2px"
      },
      "screens": {
        "sm": "375px",
        "md": "480px",
        "lg": "481px",
        "xl": "600px",
        "2xl": "640px"
      }
    }
  },
  "content": [
    "./src/**/*.{html,js,jsx,ts,tsx}"
  ]
}
```

## Page Structure

### Components
| Type | Count | Confidence |
|------|-------|------------|
| card | 40 | 100% |
| button | 19 | 100% |
| nav | 1 | 100% |
| hero | 8 | 90% |
| tabs | 1 | 80% |
| modal | 1 | 70% |
```
├── section: App Library
├── section: All-in-one AI video generator
└── features: Featured Apps
```
### Heading Hierarchy
# Create talking avatar video online
  ## All-in-one AI video generator
# App Library
  ## Featured Apps
### Interactive Elements
- **Buttons:** 28
- **Links:** 10
- **Inputs:** 1
- **Images:** 19
- **Videos:** 3

## Content

## App Library

Use HeyGen Apps to up-level your creative process

### CTA Copy
No CTAs detected

## SEO
- **Title:** HeyGen - Apps
- **Description:** Create customized videos using HeyGen's AI Video Generator, turning scripts into talking videos with customizable AI avatars in minutes, without a camera or crew.
- **OG Title:** HeyGen - AI Spokesperson Video Creator
- **OG Description:** Create customized videos using HeyGen's AI Video Generator, turning scripts into talking videos with customizable AI avatars in minutes, without a camera or crew.
- **OG Image:** https://static.heygen.ai/heygen/asset/og.png
- **Canonical:** https://app.heygen.com/

## Structured Tables

### Table 1 (div-grid)
| Creative StudioCreate now→ | Creative Studio | Create now→ |
| --- | --- | --- |
| Video PodcastCreate now→ | Video Podcast | Create now→ |
| Speech CleanupCreate now→ | Speech Cleanup | Create now→ |

### Table 2 (div-grid)
| Video PodcastNewGenerate a podcast video with multiple AI avatars. |  |  | Video PodcastNewGenerate a podcast video with multiple AI avatars. | Video PodcastNew | New |
| --- | --- | --- | --- | --- | --- |
| AI StudioCreate and produce professional avatar videos. |  |  | AI StudioCreate and produce professional avatar videos. | AI Studio |  |
| Video AgentDescribe your video and let an AI agent script and build it |  |  | Video AgentDescribe your video and let an AI agent script and build it | Video Agent |  |
| Translate VideosConvert any video into 175+ languages |  |  | Translate VideosConvert any video into 175+ languages | Translate Videos |  |
| Cinematic ShotsAI-powered cinematic, film-quality shots of your avatar. |  |  | Cinematic ShotsAI-powered cinematic, film-quality shots of your avatar. | Cinematic Shots |  |
| PPT/PDF to VideoTransform documents into engaging avatar videos |  |  | PPT/PDF to VideoTransform documents into engaging avatar videos | PPT/PDF to Video |  |
| Creative StudioNewCreate AI-generated video, images, and avatars — 20+ models all in one composer. |  |  | Creative StudioNewCreate AI-generated video, images, and avatars — 20+ models all in one composer. | Creative StudioNew | New |
| AI ClippingAdd a longer video and AI will create shortened clips. |  |  | AI ClippingAdd a longer video and AI will create shortened clips. | AI Clipping |  |
| Upscale VideoCreate high resolution outputs from your existing videos. |  |  | Upscale VideoCreate high resolution outputs from your existing videos. | Upscale Video |  |
| Batch ModeCreate multiple avatar videos at once from a spreadsheet. |  |  | Batch ModeCreate multiple avatar videos at once from a spreadsheet. | Batch Mode |  |
| Speech CleanupNewRemove unwanted pauses and words automatically |  |  | Speech CleanupNewRemove unwanted pauses and words automatically | Speech CleanupNew | New |
> ... (12 rows total)

## Export Formats

### CSS Variables
```css
/* Generated by Steal — https://steal.extension */
/* Source: https://app.heygen.com/apps | 2026-10-15 */

:root {
  /* Colors */
  --color-primary: #3e4049;
  --color-text: #e2e3e6;
  --color-background: #e5e7eb;

  /* Typography */
  --font-family-sans: "TT Norms Pro", Avenir, -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Helvetica Neue", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
  --font-size-sm: 14px;
  --font-size-base: 16px;
  --font-size-lg: 28px;
  --font-size-xl: 21px;
  --font-size-2xl: 12px;
  --font-size-3xl: 36px;
  --font-weight-normal: 400;
  --font-weight-medium: 600;
  --font-weight-semibold: 700;
  --font-weight-bold: 500;

  /* Spacing */
  --spacing-xs: 4px;
  --spacing-sm: 8px;
  --spacing-md: 10px;
  --spacing-lg: 16px;
  --spacing-xl: 20px;

  /* Border Radius */
  --radius-sm: 16px;
  --radius-md: 100px;

  /* Shadows */
  --shadow-sm: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.06) 0px 2px 4px -2px, rgba(0, 0, 0, 0.1) 0px 4px 8px -2px;

  /* Breakpoints (reference only) */
  /* 375px, 480px, 481px, 600px, 640px, 641px, 721px, 761px, 768px, 860px, 890px, 900px, 961px, 1024px, 1060px, 1150px, 1280px, 1440px, 1536px, 1920px, 2000px, 2560px */
}
```

### Design Tokens (JSON/DTCG)
```json
{
  "color": {
    "$type": "color",
    "primary": {
      "$value": "#3e4049",
      "$description": "Primary brand color"
    },
    "text": {
      "$value": "#e2e3e6"
    },
    "background": {
      "$value": "#e5e7eb"
    }
  },
  "typography": {
    "$type": "fontFamily",
    "heading": {
      "$value": [
        "TT Norms Pro",
        "Avenir",
  // ... (110 lines total)
```

---
*Powered by [Steal](https://steal.extension) — Wappalyzer, Readability, Turndown (MIT)*
*~17 tokens | 65 chars*