# MediaForge — Premium AI Creative Studio

A rebuilt premium studio with a restrained, production-grade visual system inspired by the reference products in `reference/` and the supplied avatar-studio design. The application combines avatar creation, presenter scenes, voice controls, video/image storyboards, agents, live avatar interaction, templates, brand kit, AI Director, DesignForge and local project storage in one workspace.

## Run

Requirements: Python 3.9+

```bash
python server.py
```

Open `http://localhost:8000`.

Windows: double-click `start.bat`.

## What each workspace does

Every sidebar item renders its own tool into the central canvas. Everything persists in the browser (localStorage); `server.py` supplies AI text, DesignForge and provider config.

| Item | Result |
|---|---|
| Studio | Live presenter stage + storyboard; **Publish** renders a real WebM video |
| Avatars | Pick the presenter, or create one from an uploaded photo |
| Video | Prompt → script → rendered WebM; upload a clip to trim, change speed/look, caption |
| Images | On-device generative artwork + photo editing (filters, text), PNG export, library, use as scene background |
| Voice | TTS with system voices, saved voices (used by Studio/Live), mic recording + pitch/speed transformer |
| Agents | Create agents with instructions; chat by text or mic, spoken replies (`/api/chat`) |
| Live Avatar | Hands-free listen → think → speak loop with a reactive avatar |
| Projects | Auto-saved list: open, rename, duplicate, delete, export/import JSON |
| Templates | Six structures that create a new project with scenes filled in |
| Scenes | Edit text, duration, background; reorder, duplicate, delete; render |
| Brand Kit | Colours, font, tagline, logo; applied to the stage and to renders |
| AI Director | One prompt → script, casting, brand, scenes, rendered video, with a step log |
| Memory | Persistent facts injected into agents, live sessions, scripts and Director |
| DesignForge | Website generator (`/api/generate`), preview/code/download/refine |
| Integrations | Provider status; save keys / Ollama settings to `.env` (localhost only) |
| Settings | Aspect, quality, fps, speech language, memory toggle, backup/restore/reset |

### Honest limits

- Rendered videos are **silent** WebM (browser speech output cannot be recorded) and use a static photo presenter; there is no lip-sync model.
- Image "generation" is procedural art, not a diffusion model. Voice "cloning" is not real cloning.
- ElevenLabs / Kling / HeyGen keys can be stored, but those adapters are not wired yet. Claude and Ollama are active.
- Agents fall back to a trivial offline reply when neither Ollama nor a Claude key is available.
- Recording uses `requestAnimationFrame`, so keep the tab visible while rendering. Chrome/Edge recommended.

## AI / unlimited architecture

The app does not impose an application-level credit system. Browser/local capabilities can be iterated without a MediaForge credit counter. True photorealistic cloud generation, voice cloning and streaming photorealistic avatars still require an inference backend/provider; those services can have their own pricing, quotas or hardware limits. The UI therefore exposes provider adapters rather than pretending those external limits do not exist.

For free local AI, install Ollama and run a model, for example:

```bash
ollama pull llama3.2
ollama serve
python server.py
```

The existing backend detects Ollama automatically.

## Main files

- `static/index.html` — premium MediaForge studio.
- `static/design.html` — standalone DesignForge workspace.
- `server.py` — standard-library HTTP/API server.
- `engine.py` — reference parsing, local/LLM generation and provider detection.
- `reference/` — the supplied research/reference files used to shape the product.

## Provider adapters

The current package keeps provider detection and the local engine separate. The next production step for photoreal generation is to wire authenticated adapters for providers such as ElevenLabs, Kling, Gemini or a realtime-avatar backend. This avoids coupling the entire UI to a single vendor.

## v3 visual rebuild

The Studio UI was rebuilt to remove the illustrated/cartoon treatment. It now uses a restrained monochrome palette, photographic presenter assets, dense professional controls, thin borders, minimal motion, and a real editor-style layout. The centre stage is designed to resemble a professional avatar/video production application rather than a marketing dashboard.

The preview currently uses browser-loadable photographic assets for the visual shell. Real photorealistic talking-avatar generation still requires an inference backend/provider.
