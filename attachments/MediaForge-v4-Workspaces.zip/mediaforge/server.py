"""DesignForge server (standard library only): python server.py  ->  http://localhost:8000"""
import json, os, re, time, math
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, unquote

BASE = os.path.dirname(os.path.abspath(__file__))
if os.path.exists(os.path.join(BASE, ".env")):  # tiny .env loader
    for line in open(os.path.join(BASE, ".env"), encoding="utf-8"):
        if "=" in line and not line.lstrip().startswith("#"):
            k, v = line.strip().split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip("\"'"))

import engine  # after .env so the key is visible

STATIC, DESIGNS = os.path.join(BASE, "static"), os.path.join(BASE, "designs")
os.makedirs(DESIGNS, exist_ok=True)
MIME = {".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json", ".md": "text/markdown"}
SUMMARY = ("id", "name", "url", "scheme", "palette", "bg", "fg", "accent", "font", "radius", "framework")


# Which module of the app each reference file informed, and what it covered.
MAP = [
 ("captions", "avatars", "225-avatar library, generate from text, AI twin"),
 ("visionstory-ai-avatar-generator|ai-avatar-video-generator-ai-talking", "presenter", "Script + character, lip sync, framing review, 9:16, green screen"),
 ("visionstory", "presenter", "Script + character, 720p, 9:16, green screen"),
 ("synthesia-io-features|free-ai-avatar-generator-create", "avatars", "240+ avatars, characters from a prompt, digital twin"),
 ("free-ai-avatar-generator-realistic", "avatars", "Pick avatar, write script, generate talking head"),
 ("invideo", "templates", "YouTube link to avatar, 50+ languages"),
 ("native-transformations", "videogen", "Distilled fast video model"),
 ("gemini", "videogen", "Text+image+video, extend scene, easy editing"),
 ("kling", "videogen", "Omni references, storyboard, keyframes, 30s, image gen"),
 ("image-video", "videogen", "Lipsync, consistent characters"),
 ("agents", "agents", "Agent templates, prompt-to-agent"),
 ("real-time|liveavatar", "live", "Real-time avatar sessions, API-key onboarding"),
 ("studio", "studio", "Explainer / documentary / how-to projects"),
 ("heygen", "templates", "App library"),
 ("home-veed", "presenter", "Talking video, face and voice character, templates"),
 ("synthesia", "templates", "Personalized videos from a template"),
 ("text-to-speech", "tts", "Voices, audio tags like [laughs]"),
 ("voice-changer", "voicechanger", "Upload/record audio, convert voice"),
 ("voice-creation", "voicelab", "Instant clone, professional clone, design a voice"),
]

def module_for(ref):
    key = (ref["id"] + " " + ref["url"]).lower()
    for pats, mod, note in MAP:
        if any(p in key for p in pats.split("|")): return mod, note
    return "design", "Visual style reference"

def local_chat(system, msgs):
    last = (msgs[-1]["content"] if msgs else "").lower()
    if any(w in last for w in ("hi", "hello", "hey")): return "Hello! I'm running in offline demo mode, so my answers are simple. Install Ollama (free, ollama.com) and I become fully conversational, with no credits needed."
    if "?" in last: return "Good question. In offline demo mode I can't reason about it fully, but with Ollama running (free) I would answer using my configured role."
    return "Got it. (Offline demo mode: run Ollama for real responses.)"

def local_script(topic, n):
    pts = ["Introduce " + topic, "Why it matters", "How it works", "A quick example", "Key takeaway", "Next steps"]
    pts += [f"Going deeper, part {i}" for i in range(1, max(n, 6))]
    return [{"text": f"{p}. {topic} made simple." if i == 0 else f"{p} for {topic}."} for i, p in enumerate(pts[:max(2, n)])]

class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else (json.dumps(body) if ctype == "application/json" else body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _file(self, root, rel):
        path = os.path.realpath(os.path.join(root, rel))
        if not path.startswith(os.path.realpath(root) + os.sep) or not os.path.isfile(path):
            return self._send(404, {"error": "not found"})
        self._send(200, open(path, "rb").read(), MIME.get(os.path.splitext(path)[1], "application/octet-stream"))

    def do_GET(self):
        p = unquote(urlparse(self.path).path)
        if p == "/api/health":
            return self._send(200, {"llm": engine.llm_available(), "engine": engine.backend() or "local",
                                    "model": engine.ollama_model() if engine.backend() == "ollama" else None,
                                    "references": len(engine.load_all())})
        if p == "/api/references":
            return self._send(200, [{k: r[k] for k in SUMMARY} for r in engine.load_all().values()])
        m = re.fullmatch(r"/api/references/([\w-]+)(/raw)?", p)
        if m:
            ref = engine.get_ref(m.group(1))
            if not ref: return self._send(404, {"error": "unknown reference"})
            if m.group(2): return self._send(200, engine.raw_text(ref), "text/markdown")
            return self._send(200, ref)
        if p == "/api/sources":
            out = []
            for r in engine.load_all().values():
                mod, note = module_for(r)
                out.append({"id": r["id"], "name": r["name"], "url": r["url"], "module": mod, "covers": note, "file": r["file"]})
            return self._send(200, out)
        if p == "/api/providers":
            out = [{"name": f"Ollama (free, local){' · ' + engine.ollama_model() if engine.ollama_up() else ''}", "env": "run: ollama serve", "set": engine.ollama_up()}]
            keys = {"Claude (optional)": "ANTHROPIC_API_KEY", "ElevenLabs (optional)": "ELEVENLABS_API_KEY",
                    "Kling (optional)": "KLING_API_KEY", "HeyGen (optional)": "HEYGEN_API_KEY"}
            return self._send(200, out + [{"name": n, "env": k, "set": bool(os.environ.get(k))} for n, k in keys.items()])
        if p == "/api/designs":
            files = sorted(os.listdir(DESIGNS), reverse=True)[:200]
            return self._send(200, [f for f in files if f.endswith(".json")])
        m = re.fullmatch(r"/api/designs/([\w.-]+\.json)", p)
        if m: return self._file(DESIGNS, m.group(1))
        self._file(STATIC, "index.html" if p == "/" else p.lstrip("/"))

    def _json_body(self):
        n = int(self.headers.get("Content-Length", 0))
        if n > 50_000_000: raise ValueError("payload too large")
        return json.loads(self.rfile.read(n) or b"{}")

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            if path == "/api/chat":
                d = self._json_body()
                msgs = [{"role": m["role"], "content": str(m["content"])[:50000]} for m in d.get("messages", [])[-100:] if m.get("role") in ("user", "assistant")]
                if not msgs or msgs[0]["role"] != "user": return self._send(400, {"error": "messages must start with a user turn"})
                sysmsg = (str(d.get("system", ""))[:50000] or "You are a helpful voice agent.") + "\nReply in 1-3 short spoken sentences, no markdown."
                if engine.llm_available():
                    return self._send(200, {"reply": engine.llm_text(sysmsg, msgs, 600).strip(), "engine": engine.backend()})
                return self._send(200, {"reply": local_chat(sysmsg, msgs), "engine": "local"})
            if path == "/api/script":
                d = self._json_body(); topic = str(d.get("topic", "")).strip()[:300]; n = int(d.get("scenes", 4))
                if not topic: return self._send(400, {"error": "Give a topic"})
                if engine.llm_available():
                    try:
                        raw = engine.llm_text("Write a video script as a JSON array of scene objects with a 'text' field (1-2 spoken sentences each). JSON only, no commentary.",
                                              [{"role": "user", "content": f"Topic: {topic}. Kind: {d.get('kind','explainer')}. Scenes: {n}."}], 4000)
                        m = re.search(r"\[.*\]", raw, re.S)
                        sc = [{"text": (x["text"] if isinstance(x, dict) and "text" in x else str(x))} for x in json.loads(m.group(0))] if m else []
                        if sc: return self._send(200, {"scenes": sc, "engine": engine.backend()})
                    except (ValueError, KeyError, TypeError, RuntimeError):
                        pass  # small local models sometimes break JSON: fall through to the template script
                return self._send(200, {"scenes": local_script(topic, n), "engine": "local"})
            if path == "/api/config":  # Integrations: save provider keys (this machine only)
                if self.client_address[0] not in ("127.0.0.1", "::1"): return self._send(403, {"error": "Keys can only be set from the machine running the server"})
                ok = {"ANTHROPIC_API_KEY", "ELEVENLABS_API_KEY", "KLING_API_KEY", "HEYGEN_API_KEY", "OLLAMA_MODEL", "OLLAMA_URL"}
                upd = {k: str(v).strip()[:300] for k, v in self._json_body().items() if k in ok and "\n" not in str(v) and (str(v).strip() or k.endswith("_KEY"))}
                os.environ.update(upd)
                envp = os.path.join(BASE, ".env")
                keep = [l for l in (open(envp, encoding="utf-8").read().splitlines() if os.path.exists(envp) else []) if l.split("=", 1)[0].strip() not in upd]
                open(envp, "w", encoding="utf-8").write("\n".join(keep + [f"{k}={v}" for k, v in upd.items()]) + "\n")
                engine._ol["t"] = 0  # re-probe Ollama immediately
                return self._send(200, {"saved": sorted(upd)})
        except Exception as e:
            return self._send(502, {"error": str(e)})
        if path != "/api/generate":
            return self._send(404, {"error": "not found"})
        try:
            n = int(self.headers.get("Content-Length", 0))
            if n > 50_000_000: return self._send(413, {"error": "payload too large"})
            d = json.loads(self.rfile.read(n) or b"{}")
            prompt = str(d.get("prompt", "")).strip()[:50000]
            if not prompt and not d.get("change"): return self._send(400, {"error": "Describe what to design"})
            html, used, ref = engine.generate(d.get("reference", ""), str(d.get("kind", "landing"))[:200], prompt,
                                              d.get("previous"), str(d.get("change", ""))[:50000] or None)
            name = time.strftime("%Y%m%d-%H%M%S")
            rec = {"file": name + ".json", "prompt": prompt, "kind": d.get("kind"), "reference": ref["id"], "engine": used, "html": html}
            json.dump(rec, open(os.path.join(DESIGNS, name + ".json"), "w", encoding="utf-8"))
            self._send(200, {"html": html, "engine": used, "reference": {k: ref[k] for k in SUMMARY}, "file": rec["file"]})
        except ValueError as e:
            self._send(400, {"error": str(e)})
        except Exception as e:
            self._send(502, {"error": str(e)})

    def log_message(self, *a): pass


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    print(f"DesignForge on http://localhost:{port}  |  {len(engine.load_all())} references  |  "
          f"engine: {engine.backend() or 'templates (install Ollama for free AI: https://ollama.com)'}")
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
