#!/bin/sh
cd "$(dirname "$0")"
(command -v ollama >/dev/null && (curl -s localhost:11434/api/tags >/dev/null || (ollama serve >/dev/null 2>&1 &))) 
python3 server.py
