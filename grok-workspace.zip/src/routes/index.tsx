import { createFileRoute } from "@tanstack/react-router";
import { StudioApp } from "@/components/studio/app";

export const Route = createFileRoute("/")({
  component: StudioApp,
});
